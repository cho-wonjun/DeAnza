package adapter;

public class BuildAuto extends ProxyAutomative implements UpdateAuto, CreateAuto, FixAuto{
}
