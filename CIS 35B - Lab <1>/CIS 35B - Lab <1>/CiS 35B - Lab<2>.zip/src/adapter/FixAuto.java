package adapter;

public interface FixAuto {
    public String fix ();
}
